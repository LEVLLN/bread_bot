from bread_bot.main.settings.default import *
